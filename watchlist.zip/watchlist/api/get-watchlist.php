<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once('../config/config.php');
require_once('../config/database.php');

$query = 'SELECT id, symbol, note FROM watchlist';
$result = $conn->query($query);

$stocks = [];

while ($row = $result->fetch_assoc()) {
    $stocks[] = $row;
}

echo json_encode($stocks);

$conn->close();

?>
