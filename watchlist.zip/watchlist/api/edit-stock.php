<?php
ini_set('display_errors', 1); 
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

require_once('../config/config.php');
require_once('../config/database.php');

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

// Handle GET request (fetch stock details)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get the stock ID from the URL
    if (isset($_GET['id'])) {
        $id = (int)$_GET['id'];

        // Query to fetch stock details
        $sql = "SELECT symbol, note FROM watchlist WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Stock found, return stock data
            $stock = $result->fetch_assoc();
            echo json_encode($stock);
        } else {
            // Stock not found
            http_response_code(404);
            echo json_encode(["error" => "Stock not found"]);
        }

        $stmt->close();
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Missing or invalid parameters"]);
    }
}
// Handle POST request (update stock)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $inputData = json_decode(file_get_contents('php://input'), true);
    
    if (isset($inputData['id'], $inputData['symbol'], $inputData['note'])) {
        $id = $inputData['id'];
        $symbol = $inputData['symbol'];
        $note = $inputData['note'];

        if ($id <= 0 || empty($symbol)) {
            http_response_code(400); // Bad request
            echo json_encode(["error" => "Invalid or missing parameters"]);
            exit;
        }

        $sql = "UPDATE watchlist SET symbol = ?, note = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $symbol, $note, $id);

        if ($stmt->execute() && $stmt->affected_rows > 0) {
            http_response_code(200);
            echo json_encode(["success" => true, "message" => "Stock updated successfully"]);
        } else {
            http_response_code(422);
            echo json_encode(["error" => "Failed to update stock or no changes made"]);
        }

        $stmt->close();
    } else {
        http_response_code(400); // Missing or invalid parameters
        echo json_encode(["error" => "Invalid or missing parameters"]);
    }
}

$conn->close();
?>
