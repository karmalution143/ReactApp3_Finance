<?php
ini_set('display_errors', 1); 
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

require_once('../config/config.php');
require_once('../config/database.php');

// Check for connection errors
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

// Retrieve and validate `id` parameter
if (!isset($_GET['id']) || (int)$_GET['id'] <= 0) {
    http_response_code(400); // Bad request
    echo json_encode(["error" => "Invalid or missing stock ID"]);
    exit;
}

$id = (int)$_GET['id'];
error_log("Received stock ID: " . $id);

// Prepare and execute the DELETE query
$sql = "DELETE FROM watchlist WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    http_response_code(204); // No content, successfully deleted
} else {
    http_response_code(422); // Unprocessable Entity
    echo json_encode(["error" => "Failed to delete stock or stock does not exist"]);
}

// Close connections
$stmt->close();
$conn->close();
?>
